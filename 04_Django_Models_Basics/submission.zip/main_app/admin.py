from main_app.models import Employee, Department

from django.contrib import admin

# Register your models here.

admin.site.register(Employee)
admin.site.register(Department)