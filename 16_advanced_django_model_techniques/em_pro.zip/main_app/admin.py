from django.contrib import admin

from main_app.models import Restaurant, RestaurantReview

# Register your models here.



